#
#Team : 1
#Names : Apostolopoulou Ioanna & Toloudis Panagiotis
#AEM : 03121 & 02995
#

class Id:
    def __init__(self):
        self.id = 0
    def get_id(self):
        self.id += 1
        return self.id